import { Invoice, InvoiceItem } from '../types';
import html2canvas from 'html2canvas';

/**
 * دوال تصدير الفاتورة بصيغتين: PDF وصورة
 */

/**
 * حساب السعر النهائي للعنصر مع الخصم
 */
const calculateItemTotal = (item: InvoiceItem): number => {
  const price = item.customPrice ?? item.product.unitPrice;
  let total = price * item.quantity;
  
  if (item.discount && item.discount > 0) {
    if (item.discountType === 'percentage') {
      total = total - (total * item.discount / 100);
    } else {
      total = total - item.discount;
    }
  }
  
  return Math.max(0, total);
};

/**
 * حساب المجموع الفرعي (قبل خصم الفاتورة)
 */
const calculateSubtotal = (invoice: Invoice): number => {
  return invoice.items.reduce((sum, item) => sum + calculateItemTotal(item), 0);
};

/**
 * حساب قيمة خصم الفاتورة
 */
const calculateInvoiceDiscount = (invoice: Invoice): number => {
  if (!invoice.discount || invoice.discount.amount === 0) return 0;
  
  const subtotal = calculateSubtotal(invoice);
  
  if (invoice.discount.type === 'percentage') {
    return (subtotal * invoice.discount.amount) / 100;
  }
  return invoice.discount.amount;
};

/**
 * تصدير الفاتورة كملف Excel (CSV)
 */
export const exportToExcel = (invoice: Invoice) => {
  const subtotal = calculateSubtotal(invoice);
  const discountValue = calculateInvoiceDiscount(invoice);
  const total = subtotal - discountValue;
  
  let csv = 'فاتورة مبيعات\n\n';
  
  // معلومات العميل
  if (invoice.customerInfo && (invoice.customerInfo.name || invoice.customerInfo.phone || invoice.customerInfo.address)) {
    csv += 'معلومات العميل:\n';
    if (invoice.customerInfo.name) csv += `الاسم:,${invoice.customerInfo.name}\n`;
    if (invoice.customerInfo.phone) csv += `الهاتف:,${invoice.customerInfo.phone}\n`;
    if (invoice.customerInfo.address) csv += `العنوان:,${invoice.customerInfo.address}\n`;
    csv += '\n';
  }
  
  // التاريخ
  csv += `التاريخ:,${new Date(invoice.date).toLocaleDateString('ar-IQ')}\n`;
  if (invoice.invoiceNumber) {
    csv += `رقم الفاتورة:,${invoice.invoiceNumber}\n`;
  }
  csv += '\n';
  
  // جدول المنتجات
  csv += 'المنتج,الكمية,سعر الوحدة,الخصم,الإجمالي\n';
  
  invoice.items.forEach(item => {
    const price = item.customPrice ?? item.product.unitPrice;
    const itemTotal = calculateItemTotal(item);
    const discount = item.discount && item.discount > 0 
      ? (item.discountType === 'percentage' ? `${item.discount}%` : `${item.discount} IQD`)
      : 'لا يوجد';
    
    csv += `${item.product.productName},${item.quantity},${price.toLocaleString('en-US')} IQD,${discount},${itemTotal.toLocaleString('en-US')} IQD\n`;
  });
  
  csv += '\n';
  csv += `المجموع الفرعي:,,,,${subtotal.toLocaleString('en-US')} IQD\n`;
  
  if (invoice.discount && invoice.discount.amount > 0) {
    const discountLabel = invoice.discount.type === 'percentage' 
      ? `الخصم (${invoice.discount.amount}%)` 
      : 'الخصم';
    csv += `${discountLabel}:,,,,-${discountValue.toLocaleString('en-US')} IQD\n`;
  }
  
  csv += `المجموع الكلي:,,,,${total.toLocaleString('en-US')} IQD\n`;
  csv += `,,,,${total.toLocaleString('ar-IQ')} دينار عراقي\n`;
  
  // الملاحظات
  if (invoice.notes && invoice.notes.trim()) {
    csv += '\n';
    csv += `ملاحظات:,${invoice.notes}\n`;
  }
  
  // إنشاء الملف وتحميله
  const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);
  
  link.setAttribute('href', url);
  link.setAttribute('download', `فاتورة_${new Date().getTime()}.csv`);
  link.style.visibility = 'hidden';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};

/**
 * تصدير الفاتورة كملف PDF (HTML للطباعة)
 */
export const exportToPDF = (invoice: Invoice) => {
  const subtotal = calculateSubtotal(invoice);
  const discountValue = calculateInvoiceDiscount(invoice);
  const total = subtotal - discountValue;
  
  const printWindow = window.open('', '_blank');
  if (!printWindow) {
    alert('يرجى السماح بفتح النوافذ المنبثقة لطباعة الفاتورة');
    return;
  }

  let html = `
<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>فاتورة مبيعات</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      padding: 20px;
      background: #fff;
      color: #333;
    }
    
    .invoice-container {
      max-width: 800px;
      margin: 0 auto;
      background: white;
      padding: 40px;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }
    
    .header {
      text-align: center;
      border-bottom: 3px solid #4F46E5;
      padding-bottom: 20px;
      margin-bottom: 30px;
    }
    
    .header h1 {
      color: #4F46E5;
      font-size: 32px;
      margin-bottom: 10px;
    }
    
    .header p {
      color: #666;
      font-size: 14px;
    }
    
    .info-section {
      display: flex;
      justify-content: space-between;
      margin-bottom: 30px;
      gap: 20px;
    }
    
    .info-box {
      flex: 1;
      background: #F9FAFB;
      padding: 15px;
      border-radius: 8px;
      border: 1px solid #E5E7EB;
    }
    
    .info-box h3 {
      color: #4F46E5;
      font-size: 14px;
      margin-bottom: 10px;
      border-bottom: 2px solid #4F46E5;
      padding-bottom: 5px;
    }
    
    .info-box p {
      margin: 5px 0;
      font-size: 13px;
      color: #555;
    }
    
    .info-box strong {
      color: #333;
    }
    
    table {
      width: 100%;
      border-collapse: collapse;
      margin: 20px 0;
      font-size: 13px;
    }
    
    thead {
      background: linear-gradient(135deg, #4F46E5 0%, #7C3AED 100%);
      color: white;
    }
    
    th {
      padding: 12px;
      text-align: center;
      font-weight: 600;
      font-size: 13px;
    }
    
    td {
      padding: 12px;
      text-align: center;
      border-bottom: 1px solid #E5E7EB;
    }
    
    tbody tr:hover {
      background: #F9FAFB;
    }
    
    .product-name {
      text-align: right;
      font-weight: 500;
      color: #333;
    }
    
    .total-row {
      background: #F3F4F6;
      font-weight: bold;
    }
    
    .grand-total {
      background: linear-gradient(135deg, #EEF2FF 0%, #E0E7FF 100%);
      font-size: 16px;
      color: #4F46E5;
    }
    
    .notes-section {
      margin-top: 30px;
      padding: 15px;
      background: #FFFBEB;
      border: 1px solid #FCD34D;
      border-radius: 8px;
    }
    
    .notes-section h3 {
      color: #B45309;
      font-size: 14px;
      margin-bottom: 8px;
    }
    
    .notes-section p {
      color: #78350F;
      font-size: 13px;
      line-height: 1.6;
    }
    
    .footer {
      margin-top: 40px;
      padding-top: 20px;
      border-top: 2px solid #E5E7EB;
      text-align: center;
      color: #666;
      font-size: 12px;
    }
    
    @media print {
      body {
        padding: 0;
      }
      
      .invoice-container {
        box-shadow: none;
        padding: 20px;
      }
      
      @page {
        margin: 1cm;
      }
    }
  </style>
</head>
<body>
  <div class="invoice-container">
    <div class="header">
      <h1>🧾 فاتورة مبيعات</h1>
      <p>نظام إدارة الفواتير</p>
    </div>
    
    <div class="info-section">`;

  // معلومات العميل
  if (invoice.customerInfo && (invoice.customerInfo.name || invoice.customerInfo.phone || invoice.customerInfo.address)) {
    html += `
      <div class="info-box">
        <h3>معلومات العميل</h3>`;
    
    if (invoice.customerInfo.name) {
      html += `<p><strong>الاسم:</strong> ${invoice.customerInfo.name}</p>`;
    }
    if (invoice.customerInfo.phone) {
      html += `<p><strong>الهاتف:</strong> ${invoice.customerInfo.phone}</p>`;
    }
    if (invoice.customerInfo.address) {
      html += `<p><strong>العنوان:</strong> ${invoice.customerInfo.address}</p>`;
    }
    
    html += `
      </div>`;
  }

  // معلومات الفاتورة
  html += `
      <div class="info-box">
        <h3>معلومات الفاتورة</h3>
        <p><strong>التاريخ:</strong> ${new Date(invoice.date).toLocaleDateString('ar-IQ', { 
          year: 'numeric', 
          month: 'long', 
          day: 'numeric',
          weekday: 'long'
        })}</p>
        <p><strong>الوقت:</strong> ${new Date(invoice.date).toLocaleTimeString('ar-IQ')}</p>`;
  
  if (invoice.invoiceNumber) {
    html += `<p><strong>رقم الفاتورة:</strong> ${invoice.invoiceNumber}</p>`;
  }
  
  html += `
      </div>
    </div>
    
    <table>
      <thead>
        <tr>
          <th>#</th>
          <th>المنتج</th>
          <th>الكمية</th>
          <th>سعر الوحدة</th>
          <th>الخصم</th>
          <th>الإجمالي</th>
        </tr>
      </thead>
      <tbody>`;

  // عناصر الفاتورة
  invoice.items.forEach((item, index) => {
    const price = item.customPrice ?? item.product.unitPrice;
    const itemTotal = calculateItemTotal(item);
    const discount = item.discount && item.discount > 0 
      ? (item.discountType === 'percentage' ? `${item.discount}%` : `${item.discount.toLocaleString()} IQD`)
      : '-';
    
    html += `
        <tr>
          <td>${index + 1}</td>
          <td class="product-name">${item.product.productName}</td>
          <td>${item.quantity}</td>
          <td>${price.toLocaleString('en-US')} IQD</td>
          <td>${discount}</td>
          <td><strong>${itemTotal.toLocaleString('en-US')} IQD</strong></td>
        </tr>`;
  });

  html += `
      </tbody>
      <tfoot>
        <tr class="total-row">
          <td colspan="5" style="text-align: right; padding-right: 20px;">المجموع الفرعي:</td>
          <td><strong>${subtotal.toLocaleString('en-US')} IQD</strong></td>
        </tr>`;

  // خصم الفاتورة
  if (invoice.discount && invoice.discount.amount > 0) {
    const discountLabel = invoice.discount.type === 'percentage' 
      ? `الخصم (${invoice.discount.amount}%)` 
      : 'الخصم';
    
    html += `
        <tr class="total-row">
          <td colspan="5" style="text-align: right; padding-right: 20px; color: #059669;">${discountLabel}:</td>
          <td style="color: #059669;"><strong>-${discountValue.toLocaleString('en-US')} IQD</strong></td>
        </tr>`;
  }

  html += `
        <tr class="grand-total">
          <td colspan="5" style="text-align: right; padding-right: 20px; font-size: 18px;">المجموع الكلي:</td>
          <td style="font-size: 18px;"><strong>${total.toLocaleString('en-US')} IQD</strong></td>
        </tr>
        <tr>
          <td colspan="6" style="text-align: center; padding: 15px; background: #F3F4F6; font-size: 14px;">
            <em>${total.toLocaleString('ar-IQ')} دينار عراقي فقط لا غير</em>
          </td>
        </tr>
      </tfoot>
    </table>`;

  // الملاحظات
  if (invoice.notes && invoice.notes.trim()) {
    html += `
    <div class="notes-section">
      <h3>📝 ملاحظات:</h3>
      <p>${invoice.notes}</p>
    </div>`;
  }

  html += `
    <div class="footer">
      <p>شكراً لتعاملكم معنا 🙏</p>
      <p>تم إنشاء هذه الفاتورة بواسطة نظام إدارة الفواتير</p>
    </div>
  </div>
  
  <script>
    window.onload = function() {
      window.print();
    };
  </script>
</body>
</html>`;

  printWindow.document.write(html);
  printWindow.document.close();
};

/**
 * تصدير الفاتورة كصورة PNG
 */
export const exportToImage = async (invoice: Invoice) => {
  const subtotal = calculateSubtotal(invoice);
  const discountValue = calculateInvoiceDiscount(invoice);
  const total = subtotal - discountValue;
  
  // إنشاء عنصر HTML مؤقت للفاتورة
  const invoiceElement = document.createElement('div');
  invoiceElement.style.cssText = `
    position: absolute;
    left: -9999px;
    top: 0;
    width: 800px;
    background: white;
    padding: 40px;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    direction: rtl;
  `;
  
  let html = `
    <div style="background: white; padding: 40px; border: 2px solid #4F46E5; border-radius: 10px;">
      <div style="text-align: center; border-bottom: 3px solid #4F46E5; padding-bottom: 20px; margin-bottom: 30px;">
        <h1 style="color: #4F46E5; font-size: 32px; margin: 0 0 10px 0;">🧾 فاتورة مبيعات</h1>
        <p style="color: #666; font-size: 14px; margin: 0;">نظام إدارة الفواتير</p>
      </div>
      
      <div style="display: flex; gap: 20px; margin-bottom: 30px;">`;
  
  // معلومات العميل
  if (invoice.customerInfo && (invoice.customerInfo.name || invoice.customerInfo.phone || invoice.customerInfo.address)) {
    html += `
        <div style="flex: 1; background: #F9FAFB; padding: 15px; border-radius: 8px; border: 1px solid #E5E7EB;">
          <h3 style="color: #4F46E5; font-size: 14px; margin: 0 0 10px 0; border-bottom: 2px solid #4F46E5; padding-bottom: 5px;">معلومات العميل</h3>`;
    
    if (invoice.customerInfo.name) {
      html += `<p style="margin: 5px 0; font-size: 13px;"><strong>الاسم:</strong> ${invoice.customerInfo.name}</p>`;
    }
    if (invoice.customerInfo.phone) {
      html += `<p style="margin: 5px 0; font-size: 13px;"><strong>الهاتف:</strong> ${invoice.customerInfo.phone}</p>`;
    }
    if (invoice.customerInfo.address) {
      html += `<p style="margin: 5px 0; font-size: 13px;"><strong>العنوان:</strong> ${invoice.customerInfo.address}</p>`;
    }
    
    html += `</div>`;
  }
  
  // معلومات الفاتورة
  html += `
        <div style="flex: 1; background: #F9FAFB; padding: 15px; border-radius: 8px; border: 1px solid #E5E7EB;">
          <h3 style="color: #4F46E5; font-size: 14px; margin: 0 0 10px 0; border-bottom: 2px solid #4F46E5; padding-bottom: 5px;">معلومات الفاتورة</h3>
          <p style="margin: 5px 0; font-size: 13px;"><strong>التاريخ:</strong> ${new Date(invoice.date).toLocaleDateString('ar-IQ')}</p>
          <p style="margin: 5px 0; font-size: 13px;"><strong>الوقت:</strong> ${new Date(invoice.date).toLocaleTimeString('ar-IQ')}</p>`;
  
  if (invoice.invoiceNumber) {
    html += `<p style="margin: 5px 0; font-size: 13px;"><strong>رقم الفاتورة:</strong> ${invoice.invoiceNumber}</p>`;
  }
  
  html += `
        </div>
      </div>
      
      <table style="width: 100%; border-collapse: collapse; margin: 20px 0; font-size: 13px;">
        <thead>
          <tr style="background: linear-gradient(135deg, #4F46E5 0%, #7C3AED 100%); color: white;">
            <th style="padding: 12px; text-align: center;">#</th>
            <th style="padding: 12px; text-align: center;">المنتج</th>
            <th style="padding: 12px; text-align: center;">الكمية</th>
            <th style="padding: 12px; text-align: center;">سعر الوحدة</th>
            <th style="padding: 12px; text-align: center;">الخصم</th>
            <th style="padding: 12px; text-align: center;">الإجمالي</th>
          </tr>
        </thead>
        <tbody>`;
  
  // عناصر الفاتورة
  invoice.items.forEach((item, index) => {
    const price = item.customPrice ?? item.product.unitPrice;
    const itemTotal = calculateItemTotal(item);
    const discount = item.discount && item.discount > 0 
      ? (item.discountType === 'percentage' ? `${item.discount}%` : `${item.discount.toLocaleString()} IQD`)
      : '-';
    
    html += `
          <tr style="border-bottom: 1px solid #E5E7EB;">
            <td style="padding: 12px; text-align: center;">${index + 1}</td>
            <td style="padding: 12px; text-align: right; font-weight: 500;">${item.product.productName}</td>
            <td style="padding: 12px; text-align: center;">${item.quantity}</td>
            <td style="padding: 12px; text-align: center;">${price.toLocaleString('en-US')} IQD</td>
            <td style="padding: 12px; text-align: center;">${discount}</td>
            <td style="padding: 12px; text-align: center;"><strong>${itemTotal.toLocaleString('en-US')} IQD</strong></td>
          </tr>`;
  });
  
  html += `
        </tbody>
        <tfoot>
          <tr style="background: #F3F4F6; font-weight: bold;">
            <td colspan="5" style="padding: 12px; text-align: right;">المجموع الفرعي:</td>
            <td style="padding: 12px; text-align: center;"><strong>${subtotal.toLocaleString('en-US')} IQD</strong></td>
          </tr>`;
  
  // خصم الفاتورة
  if (invoice.discount && invoice.discount.amount > 0) {
    const discountLabel = invoice.discount.type === 'percentage' 
      ? `الخصم (${invoice.discount.amount}%)` 
      : 'الخصم';
    
    html += `
          <tr style="background: #F3F4F6; font-weight: bold;">
            <td colspan="5" style="padding: 12px; text-align: right; color: #059669;">${discountLabel}:</td>
            <td style="padding: 12px; text-align: center; color: #059669;"><strong>-${discountValue.toLocaleString('en-US')} IQD</strong></td>
          </tr>`;
  }
  
  html += `
          <tr style="background: linear-gradient(135deg, #EEF2FF 0%, #E0E7FF 100%); font-size: 16px; color: #4F46E5;">
            <td colspan="5" style="padding: 15px; text-align: right; font-size: 18px;"><strong>المجموع الكلي:</strong></td>
            <td style="padding: 15px; text-align: center; font-size: 18px;"><strong>${total.toLocaleString('en-US')} IQD</strong></td>
          </tr>
          <tr>
            <td colspan="6" style="padding: 15px; text-align: center; background: #F3F4F6; font-size: 14px;">
              <em>${total.toLocaleString('ar-IQ')} دينار عراقي فقط لا غير</em>
            </td>
          </tr>
        </tfoot>
      </table>`;
  
  // الملاحظات
  if (invoice.notes && invoice.notes.trim()) {
    html += `
      <div style="margin-top: 30px; padding: 15px; background: #FFFBEB; border: 1px solid #FCD34D; border-radius: 8px;">
        <h3 style="color: #B45309; font-size: 14px; margin: 0 0 8px 0;">📝 ملاحظات:</h3>
        <p style="color: #78350F; font-size: 13px; margin: 0; line-height: 1.6;">${invoice.notes}</p>
      </div>`;
  }
  
  html += `
      <div style="margin-top: 40px; padding-top: 20px; border-top: 2px solid #E5E7EB; text-align: center; color: #666; font-size: 12px;">
        <p style="margin: 5px 0;">شكراً لتعاملكم معنا 🙏</p>
        <p style="margin: 5px 0;">تم إنشاء هذه الفاتورة بواسطة نظام إدارة الفواتير</p>
      </div>
    </div>`;
  
  invoiceElement.innerHTML = html;
  document.body.appendChild(invoiceElement);
  
  try {
    // التقاط الصورة
    const canvas = await html2canvas(invoiceElement, {
      backgroundColor: '#ffffff',
      scale: 2, // دقة عالية
      logging: false,
      useCORS: true
    });
    
    // تحويل إلى صورة وتحميلها
    canvas.toBlob((blob) => {
      if (blob) {
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `فاتورة_${new Date().getTime()}.png`;
        link.click();
        URL.revokeObjectURL(url);
      }
    }, 'image/png');
  } catch (error) {
    console.error('خطأ في تصدير الصورة:', error);
    alert('حدث خطأ أثناء تصدير الصورة');
  } finally {
    // إزالة العنصر المؤقت
    document.body.removeChild(invoiceElement);
  }
};
