import { Product } from '../types';

/**
 * خدمة جلب البيانات من Google Sheets
 * تستخدم الطريقة المبسطة بدون API رسمي
 */

// رابط Google Sheet المنشور الخاص بك
// هذا الرابط يأتي من "Publish to web" ويعمل مباشرة
const PUBLISHED_URL = 'https://docs.google.com/spreadsheets/d/e/2PACX-1vSJ2LkUIP6It4DqYJUKO4QtF8SWq1PvdS7NOkfaqbiAfFVicy3COWOPt0KNAtUQLQtQel3lyZWUOKj1/pub?output=csv';

// استخدام الرابط المنشور
const SHEET_URL = PUBLISHED_URL;

// متغير لتتبع مصدر البيانات (للإشارة إلى استخدام البيانات التجريبية أو الحقيقية)
let isUsingDemoData = false;

/**
 * التحقق من استخدام البيانات التجريبية
 */
export function getIsUsingDemoData(): boolean {
  return isUsingDemoData;
}

/**
 * جلب البيانات من Google Sheet
 * @returns قائمة المنتجات
 */
export async function fetchProductsFromSheet(): Promise<Product[]> {
  try {
    console.log('🔄 جاري جلب البيانات من Google Sheets...');
    console.log('📊 الرابط:', SHEET_URL);
    
    // محاولة جلب البيانات من الرابط
    const response = await fetch(SHEET_URL, {
      mode: 'cors',
      cache: 'no-cache'
    });
    
    if (!response.ok) {
      throw new Error(`فشل الاتصال بـ Google Sheets: ${response.status}`);
    }
    
    const csvText = await response.text();
    console.log('✅ تم جلب البيانات بنجاح');
    
    // تحويل CSV إلى JSON
    const products = parseCSV(csvText);
    
    if (products.length === 0) {
      console.warn('⚠️ لم يتم العثور على منتجات في الجدول، استخدام البيانات التجريبية');
      isUsingDemoData = true;
      return getDemoData();
    }
    
    console.log(`✅ تم تحميل ${products.length} منتج من Google Sheets`);
    isUsingDemoData = false;
    return products;
    
  } catch (error) {
    console.error('❌ خطأ في جلب البيانات من Google Sheets:', error);
    console.log('🔄 استخدام البيانات التجريبية بدلاً من ذلك...');
    
    // في حالة الفشل، إرجاع بيانات تجريبية
    isUsingDemoData = true;
    return getDemoData();
  }
}

/**
 * تحويل نص CSV إلى قائمة منتجات
 * يدعم معالجة النصوص المحاطة بعلامات اقتباس
 * @param csvText النص بصيغة CSV
 * @returns قائمة المنتجات
 */
function parseCSV(csvText: string): Product[] {
  const lines = csvText.split('\n').filter(line => line.trim());
  const products: Product[] = [];
  
  // تجاهل السطر الأول (العناوين)
  for (let i = 1; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;
    
    // تحليل CSV مع دعم علامات الاقتباس
    const values = parseCSVLine(line);
    
    // التأكد من وجود 4 أعمدة على الأقل: الاسم، المجموعة، السعر، الكمية
    if (values.length >= 4) {
      const product: Product = {
        productName: values[0].trim(),      // العمود الأول: الاسم
        group: values[1].trim(),            // العمود الثاني: المجموعة
        unitPrice: parseFloat(values[2].replace(/[^\d.]/g, '')) || 0,  // العمود الثالث: السعر
        availableQty: parseInt(values[3].replace(/[^\d]/g, '')) || 0   // العمود الرابع: الكمية
      };
      
      // تجاهل الصفوف الفارغة أو غير الصالحة
      if (product.productName && product.group) {
        products.push(product);
      }
    }
  }
  
  return products;
}

/**
 * تحليل سطر CSV واحد مع دعم علامات الاقتباس
 * @param line سطر CSV
 * @returns مصفوفة القيم
 */
function parseCSVLine(line: string): string[] {
  const values: string[] = [];
  let current = '';
  let inQuotes = false;
  
  for (let i = 0; i < line.length; i++) {
    const char = line[i];
    
    if (char === '"') {
      inQuotes = !inQuotes;
    } else if (char === ',' && !inQuotes) {
      values.push(current);
      current = '';
    } else {
      current += char;
    }
  }
  
  values.push(current);
  return values.map(v => v.trim().replace(/^"|"$/g, ''));
}

/**
 * بيانات تجريبية للاختبار
 * يمكن استخدامها عندما لا يتوفر اتصال بـ Google Sheets
 */
function getDemoData(): Product[] {
  return [
    // مجموعة الإلكترونيات
    { group: 'إلكترونيات', productName: 'لابتوب HP ProBook', availableQty: 15, unitPrice: 3500 },
    { group: 'إلكترونيات', productName: 'ماوس لاسلكي Logitech', availableQty: 50, unitPrice: 85 },
    { group: 'إلكترونيات', productName: 'كيبورد ميكانيكي', availableQty: 30, unitPrice: 250 },
    { group: 'إلكترونيات', productName: 'شاشة Dell 27 بوصة', availableQty: 20, unitPrice: 1200 },
    { group: 'إلكترونيات', productName: 'سماعات Bluetooth', availableQty: 45, unitPrice: 150 },
    
    // مجموعة المكتبيات
    { group: 'مكتبيات', productName: 'دفتر ملاحظات A4', availableQty: 200, unitPrice: 15 },
    { group: 'مكتبيات', productName: 'قلم حبر أزرق', availableQty: 500, unitPrice: 3 },
    { group: 'مكتبيات', productName: 'مجلد ملفات بلاستيك', availableQty: 150, unitPrice: 8 },
    { group: 'مكتبيات', productName: 'آلة حاسبة علمية', availableQty: 35, unitPrice: 45 },
    { group: 'مكتبيات', productName: 'مقص مكتبي', availableQty: 60, unitPrice: 12 },
    
    // مجموعة الأثاث
    { group: 'أثاث', productName: 'كرسي مكتب مريح', availableQty: 25, unitPrice: 800 },
    { group: 'أثاث', productName: 'طاولة مكتب خشبية', availableQty: 18, unitPrice: 1500 },
    { group: 'أثاث', productName: 'خزانة ملفات معدنية', availableQty: 12, unitPrice: 950 },
    { group: 'أثاث', productName: 'رف كتب خشبي', availableQty: 22, unitPrice: 600 },
    { group: 'أثاث', productName: 'طاولة اجتماعات', availableQty: 8, unitPrice: 3200 },
    
    // مجموعة الطباعة
    { group: 'طباعة', productName: 'طابعة ليزر HP', availableQty: 10, unitPrice: 2200 },
    { group: 'طباعة', productName: 'حبر طابعة أسود', availableQty: 80, unitPrice: 120 },
    { group: 'طباعة', productName: 'حبر طابعة ملون', availableQty: 65, unitPrice: 180 },
    { group: 'طباعة', productName: 'ورق طباعة A4 (500 ورقة)', availableQty: 100, unitPrice: 35 },
    { group: 'طباعة', productName: 'ماسح ضوئي Canon', availableQty: 15, unitPrice: 850 },
  ];
}

/**
 * استخراج قائمة المجموعات الفريدة
 * @param products قائمة المنتجات
 * @returns قائمة المجموعات
 */
export function getUniqueGroups(products: Product[]): string[] {
  const groups = products.map(p => p.group);
  return Array.from(new Set(groups)).sort();
}

/**
 * تصفية المنتجات حسب المجموعة
 * @param products قائمة المنتجات
 * @param group المجموعة المطلوبة
 * @returns المنتجات المصفاة
 */
export function filterByGroup(products: Product[], group: string): Product[] {
  if (!group) return products;
  return products.filter(p => p.group === group);
}

/**
 * البحث في المنتجات
 * @param products قائمة المنتجات
 * @param searchTerm نص البحث
 * @returns المنتجات المطابقة
 */
export function searchProducts(products: Product[], searchTerm: string): Product[] {
  if (!searchTerm) return products;
  
  const term = searchTerm.toLowerCase();
  return products.filter(p => 
    p.productName.toLowerCase().includes(term) ||
    p.group.toLowerCase().includes(term)
  );
}
