// تعريف أنواع البيانات المستخدمة في التطبيق

// نوع بيانات المنتج من Google Sheet
export interface Product {
  group: string;           // المجموعة
  productName: string;     // اسم المنتج
  availableQty: number;    // الكمية المتاحة
  unitPrice: number;       // سعر الوحدة
}

// نوع بيانات عنصر الفاتورة
export interface InvoiceItem {
  product: Product;        // بيانات المنتج
  quantity: number;        // الكمية المطلوبة
  customPrice?: number;    // السعر المخصص (قابل للتعديل)
  discount?: number;       // الخصم على المنتج (نسبة مئوية أو مبلغ ثابت)
  discountType?: 'percentage' | 'fixed'; // نوع الخصم
  totalPrice: number;      // السعر الإجمالي للعنصر
}

// نوع بيانات معلومات العميل
export interface CustomerInfo {
  name: string;            // اسم العميل
  address: string;         // عنوان العميل
  phone: string;           // رقم هاتف العميل
}

// نوع بيانات الخصم على الفاتورة
export interface InvoiceDiscount {
  amount: number;          // قيمة الخصم
  type: 'percentage' | 'fixed'; // نوع الخصم (نسبة مئوية أو مبلغ ثابت)
}

// نوع بيانات الفاتورة الكاملة
export interface Invoice {
  items: InvoiceItem[];              // عناصر الفاتورة
  customerInfo?: CustomerInfo;       // معلومات العميل (اختياري)
  notes?: string;                    // ملاحظات الفاتورة (اختياري)
  discount?: InvoiceDiscount;        // خصم على إجمالي الفاتورة (اختياري)
  subtotal: number;                  // المجموع قبل الخصم
  totalAmount: number;               // المبلغ الإجمالي بعد الخصم
  date: Date;                        // تاريخ الفاتورة
  invoiceNumber?: string;            // رقم الفاتورة (اختياري)
}
